# AI Nose

AI nose based on [Benjamin Cabé's artificial nose project](https://github.com/kartben/artificial-nose).

If you would like to construct this project yourself, follow the directions in [this tutorial](https://www.digikey.com/en/maker/projects/how-to-make-an-ai-powered-artificial-nose/3fcf88a89efa47a1b231c5ad2097716a).

## License

Unless otherwise specified, all code is licensed under the [Zero-Cluase BSD license (0BSD)](https://opensource.org/licenses/0BSD).

Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.